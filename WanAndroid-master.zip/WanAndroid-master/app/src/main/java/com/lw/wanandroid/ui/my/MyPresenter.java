package com.lw.wanandroid.ui.my;

import com.lw.wanandroid.base.BasePresenter;

import javax.inject.Inject;

/**
 * Created by lw on 2018/1/19.
 */

public class MyPresenter extends BasePresenter<MyContract.View> implements MyContract.Presenter {
    @Inject
    public MyPresenter() {

    }
}
